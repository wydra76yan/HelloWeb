CREATE VIEW vphones AS
  SELECT
    `test`.`phonebook`.`phone`    AS `phone`,
    `test`.`phonebook`.`lastname` AS `lastname`
  FROM `test`.`phonebook`;
