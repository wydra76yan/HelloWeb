CREATE PROCEDURE getlastname(IN p_phone BIGINT, OUT p_lastname VARCHAR(250))
  BEGIN
	SELECT lastname INTO p_lastname FROM phonebook WHERE phone = p_phone;
	END;
